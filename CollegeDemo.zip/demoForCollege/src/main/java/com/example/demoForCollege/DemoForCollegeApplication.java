package com.example.demoForCollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoForCollegeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoForCollegeApplication.class, args);
	}

}
