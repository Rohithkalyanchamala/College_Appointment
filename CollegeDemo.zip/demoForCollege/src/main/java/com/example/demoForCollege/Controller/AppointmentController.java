package com.example.demoForCollege.Controller;

import com.example.demoForCollege.entity.Appointment;
import com.example.demoForCollege.Service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/appointment")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @PostMapping("/book")
    public ResponseEntity<String> bookAppointment(@Validated @RequestBody Appointment appointment) {
        
        if (appointment.getTimeSlot() == null || appointment.getTimeSlot().isEmpty()) {
            return ResponseEntity.badRequest().body("Error: Time slot cannot be null or empty");
        }

       
        String timeSlot = appointment.getTimeSlot().toUpperCase();  // Convert to uppercase for case insensitivity
        if (!timeSlot.equals("MORNING") && !timeSlot.equals("EVENING")) {
            return ResponseEntity.badRequest().body("Error: Invalid time slot value. Please use 'MORNING' or 'EVENING'");
        }

       
        try {
            appointment.setTimeSlot(timeSlot);  
            appointmentService.bookAppointment(appointment);
            return ResponseEntity.status(HttpStatus.CREATED).body("Appointment booked successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error: " + e.getMessage());
        }
    }




    
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Appointment>> getAppointmentsByUserId(@PathVariable Long userId) {
        List<Appointment> appointments = appointmentService.getAppointmentsByUserId(userId);
        return ResponseEntity.ok(appointments);
    }

 
    @GetMapping("/professor/{professorId}")
    public ResponseEntity<List<Appointment>> getAppointmentsByProfessorId(@PathVariable Long professorId) {
        List<Appointment> appointments = appointmentService.getAppointmentsByProfessorId(professorId);
        return ResponseEntity.ok(appointments);
    }
    
  
    @DeleteMapping("/remove/{studentId}")
    public ResponseEntity<String> deleteAppointment(@PathVariable Long studentId) {
        appointmentService.deleteAppointment(studentId);
      
      return ResponseEntity.ok("Appointment deleted successfully");
    }
    
}
