package com.example.demoForCollege;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class AppointmentSystemE2ETest {

	@Autowired
	private MockMvc mockMvc;

	@Test
	void testCompleteAppointmentFlow() throws Exception {
		// Student A1 authenticates
		MvcResult studentA1Login = mockMvc.perform(post("localhost:9898/api/user/authenticate")
				.content("{\"username\": \"A1\", \"password\": \"password123\"}").contentType("application/json"))
				.andExpect(status().isOk()).andReturn();

		String studentA1Token = extractToken(studentA1Login);

		// Professor P1 authenticates
		MvcResult professorP1Login = mockMvc.perform(post("localhost:9898/api/user/authenticate")
				.content("{\"username\": \"P1\", \"password\": \"professor123\"}").contentType("application/json"))
				.andExpect(status().isOk()).andReturn();

		String professorP1Token = extractToken(professorP1Login);

		// Professor P1 specifies available time slots
		mockMvc.perform(
				post("localhost:9898/api/availability/set").header("Authorization", "Bearer " + professorP1Token)
						.content("{\"timeSlots\": [\"2024-12-08T10:00\", \"2024-12-08T11:00\"]}")
						.contentType("application/json"))
				.andExpect(status().isOk());

		// Student A1 views available time slots for Professor P1
		mockMvc.perform(get("localhost:9898/api/availability/professor/{professorId}").header("Authorization",
				"Bearer " + studentA1Token)).andExpect(status().isOk())
				.andExpect(jsonPath("$.availableTimeSlots[0]").value("2024-12-08T10:00"))
				.andExpect(jsonPath("$.availableTimeSlots[1]").value("2024-12-08T11:00"));

		// Student A1 books an appointment with Professor P1 for time T1
		mockMvc.perform(post("localhost:9898/api/appointment/book").header("Authorization", "Bearer " + studentA1Token)
				.content("{\"professorId\": \"1\", \"timeSlot\": \"2024-12-08T10:00\"}")
				.contentType("application/json")).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Appointment booked successfully"));

		// Student A2 authenticates
		MvcResult studentA2Login = mockMvc.perform(post("localhost:9898/api/user/authenticate")
				.content("{\"username\": \"A2\", \"password\": \"password321\"}").contentType("application/json"))
				.andExpect(status().isOk()).andReturn();

		String studentA2Token = extractToken(studentA2Login);

		// Student A2 books an appointment with Professor P1 for time T2
		mockMvc.perform(post("localhost:9898/api/appointment/book").header("Authorization", "Bearer " + studentA2Token)
				.content("{\"professorId\": \"1\", \"timeSlot\": \"2024-12-08T11:00\"}")
				.contentType("application/json")).andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Appointment booked successfully"));

		// Professor P1 cancels the appointment with Student A1
		mockMvc.perform(delete("localhost:9898/api/appointment/remove/{studentId}")
				.header("Authorization", "Bearer " + professorP1Token)
				.content("{\"studentId\": \"1\", \"timeSlot\": \"2024-12-08T10:00\"}").contentType("application/json"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message").value("Appointment cancelled successfully"));

		// Student A1 checks their appointments and realizes they do not have any
		// pending appointments
		mockMvc.perform(get("/student/1/appointments").header("Authorization", "Bearer " + studentA1Token))
				.andExpect(status().isOk()).andExpect(jsonPath("$.appointments").isEmpty());
	}

	private String extractToken(MvcResult result) throws Exception {
		// Logic to extract JWT token from response
		return result.getResponse().getContentAsString().split(":")[1].split("\"")[1];
	}
}
