package com.example.demoForCollege.Service;

import com.example.demoForCollege.entity.Appointment;

import jakarta.transaction.Transactional;

import com.example.demoForCollege.Repository.AppointmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepo appointmentRepository;

	public Appointment bookAppointment(Appointment appointment) {

		return appointmentRepository.save(appointment);
	}

	public List<Appointment> getAppointmentsByUserId(Long userId) {
		return appointmentRepository.findByUser_Id(userId);
	}

	public List<Appointment> getAppointmentsByProfessorId(Long professorId) {
		return appointmentRepository.findByProfessorId(professorId);
	}

	public List<Appointment> getAppointmentsByProfessorAndTimeSlot(Long professorId, String timeSlot) {
		return appointmentRepository.findByProfessorIdAndTimeSlot(professorId, timeSlot);
	}

	public List<Appointment> getAppointmentsByStudentAndTimeSlot(Long studentId, String timeSlot) {
		return appointmentRepository.findByStudentIdAndTimeSlot(studentId, timeSlot);
	}

	public void cancelAppointment(Long appointmentId) {
		appointmentRepository.deleteById(appointmentId);

	}

	@Transactional
	public void deleteAppointment(Long studentId) {
		appointmentRepository.deleteByStudentId(studentId);
	}

}
