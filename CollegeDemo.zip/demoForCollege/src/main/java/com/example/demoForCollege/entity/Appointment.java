package com.example.demoForCollege.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import org.antlr.v4.runtime.misc.NotNull;

import jakarta.persistence.Column;




@Entity
public class Appointment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Primary key
    
  @ManyToOne
  @JoinColumn(name = "ref_id",nullable=false)  // This will create a foreign key in the appointment table
    private User user;

    // Getter and setter for user
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    
//    @Column(nullable = false)
    private Long studentId;  
    
    @Column(nullable = false)
    private Long professorId;  
   
    @NotNull
    private String timeSlot;  

    public Appointment() {}

  
    public Appointment(Long studentId, Long professorId, String timeSlot) {
        this.studentId = studentId;
        this.professorId = professorId;
        this.timeSlot = timeSlot;
    }

   
    public Long getId() {
        return id;
    }
   
    public void setId(Long id) {
        this.id = id;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public Long getProfessorId() {
        return professorId;
    }

    public void setProfessorId(Long professorId) {
        this.professorId = professorId;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }
}

