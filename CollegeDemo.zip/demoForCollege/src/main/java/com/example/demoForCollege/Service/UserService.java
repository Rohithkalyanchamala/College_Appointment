package com.example.demoForCollege.Service;

import com.example.demoForCollege.entity.User;
import com.example.demoForCollege.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepository;

	public boolean authenticate(String username, String password) {
		Optional<User> user = userRepository.findByUsername(username);
		return user.isPresent() && user.get().getPassword().equals(password);
	}

	public User getUserById(Long id) {
		return userRepository.findById(id).orElse(null);
	}

	public void addUser(User user) {
		if (user != null) {
			userRepository.save(user);
		} else {
			throw new IllegalArgumentException("User cannot be null");
		}
	}

	public Optional<User> getUserByUsername(String username) {
		return userRepository.findByUsername(username);
	}
}
