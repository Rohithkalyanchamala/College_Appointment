package com.example.demoForCollege.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demoForCollege.entity.Availability;
import java.util.List;

public interface AvailabilityRepo extends JpaRepository<Availability, Long> {

	List<Availability> findByProfessorId(Long ProfessorId);

	List<Availability> findByStatus(String status);

}
