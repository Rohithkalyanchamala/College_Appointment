package com.example.demoForCollege.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demoForCollege.entity.Appointment;
import com.example.demoForCollege.entity.Availability;

import jakarta.transaction.Transactional;

import java.util.List;

public interface AppointmentRepo extends JpaRepository<Appointment, Long> {
	List<Appointment> findByUser_Id(Long id);

	void deleteByStudentId(@Param("student_id") Long studentId);

	List<Appointment> findByProfessorId(Long professorId);

	List<Appointment> findByProfessorIdAndTimeSlot(Long professorId, String timeSlot);

	List<Appointment> findByStudentIdAndTimeSlot(Long studentId, String timeSlot);

}